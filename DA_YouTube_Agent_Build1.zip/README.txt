# DA YouTube Agent — first build

## Files
- `youtube-studio.html`: separate Android-friendly dashboard page.
- `api/youtube-agent.js`: Vercel serverless API. Reads secrets from environment variables only.

## Install without replacing your existing site
1. In GitHub open `DANIYALEJAZ7865/index.html`.
2. Add `youtube-studio.html` at the repository root.
3. Add `api/youtube-agent.js` (create the `api` folder if needed).
4. Commit both files. Do not replace your existing `index.html`.
5. In Vercel, confirm the project is linked to this repository and redeploy.
6. Open `https://YOUR-EXISTING-DOMAIN/youtube-studio.html`.

## Vercel environment variables
Add `OPENAI_API_KEY` as an encrypted Environment Variable for Production (and Preview if desired). Optionally add `OPENAI_MODEL` (default in code is `gpt-6-luna`).
For trend research, create a Google Cloud project, enable YouTube Data API v3, create a restricted API key, then add it as `YOUTUBE_API_KEY`. Restrict it to YouTube Data API v3 and server-side use where possible.
Never place these values in HTML, GitHub, or chat. Redeploy after adding variables.

## Current limits
- Script/SEO/scene prompt generation works after the OpenAI key is configured.
- Trend lookup is a recent-video sample, not official YouTube Trending. Approximate views/hour is lifetime views divided by age.
- Script and video approvals are stored in this browser only; they are not yet durable or shared across devices.
- This first build does NOT render MP4 files or upload to YouTube. You must produce the video with a separate tool and review it. Upload integration needs Google OAuth consent, secure server-side token storage (for example, a database), and an explicit final publish action.
- Do not add OAuth client secrets or refresh tokens to browser code.

## Existing dashboard
The current `index.html` is not modified. Once this add-on is tested, you may add a navigation link to `youtube-studio.html` as a separate, deliberate edit.
