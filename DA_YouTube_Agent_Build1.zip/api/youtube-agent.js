// Vercel serverless function: secrets are read only on the server.
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const body = req.body || {};
  if (body.action === "trends") return trends(body, res);
  if (body.action !== "generate") return res.status(400).json({ error: "Unknown action" });

  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(503).json({ error: "Add OPENAI_API_KEY in Vercel Environment Variables." });

  const topic = String(body.topic || "").slice(0, 240);
  if (!topic) return res.status(400).json({ error: "Enter a topic." });
  const format = String(body.format || "Long fantasy episode").slice(0, 100);
  const style = String(body.style || "Cinematic fantasy").slice(0, 100);
  const language = String(body.language || "English").slice(0, 40);
  const brief = String(body.brief || "").slice(0, 5000);

  const prompt = `You are DA YouTube Automation Agent for @dachannel786. Create an original, monetization-conscious video package. The owner must approve the script before production and approve the final video before publishing. Never promise virality or invent verified trend data.
Topic: ${topic}
Format: ${format}
Style: ${style}
Language: ${language}
Brief: ${brief}
Return sections: (1) concept and hook, (2) complete script with narration/dialogue and timings, (3) scene-by-scene video prompts with consistent characters and camera instructions, (4) five honest SEO title options, (5) recommended title, (6) engaging description, (7) relevant comma-separated tags, (8) thumbnail prompt, (9) chapters for long videos, (10) rights/quality checklist. Make the story original; do not copy existing episodes or scripts.`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-6-luna", input: prompt })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "AI request failed." });
    const output = (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n");
    return res.status(200).json({ output });
  } catch {
    return res.status(500).json({ error: "AI request failed. Try again." });
  }
}

async function trends(body, res) {
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) return res.status(503).json({ error: "Add YOUTUBE_API_KEY in Vercel Environment Variables." });
  const query = String(body.topic || "fantasy animation").slice(0, 100);
  const duration = body.format === "short" ? "short" : "long";
  try {
    const params = new URLSearchParams({
      part: "snippet", type: "video", q: query, maxResults: "10", order: "viewCount",
      videoDuration: duration, publishedAfter: new Date(Date.now() - 7 * 86400000).toISOString(), key
    });
    const search = await fetch("https://www.googleapis.com/youtube/v3/search?" + params);
    const found = await search.json();
    if (!search.ok) return res.status(search.status).json({ error: found.error?.message || "YouTube search failed." });
    const ids = (found.items || []).map(x => x.id?.videoId).filter(Boolean);
    if (!ids.length) return res.status(200).json({ output: "No recent videos found. Try a broader topic." });
    const statsParams = new URLSearchParams({ part: "statistics,snippet", id: ids.join(","), key });
    const stats = await fetch("https://www.googleapis.com/youtube/v3/videos?" + statsParams);
    const data = await stats.json();
    if (!stats.ok) return res.status(stats.status).json({ error: data.error?.message || "Statistics unavailable." });
    const rows = (data.items || []).map(v => {
      const ageHours = Math.max(1, (Date.now() - Date.parse(v.snippet.publishedAt)) / 3600000);
      const views = Number(v.statistics.viewCount || 0);
      return { title: v.snippet.title, channel: v.snippet.channelTitle, views, approxVph: Math.round(views / ageHours), url: "https://www.youtube.com/watch?v=" + v.id };
    }).sort((a,b) => b.approxVph - a.approxVph);
    return res.status(200).json({ output: "Recent public videos for: " + query + "\nApprox. views/hour = lifetime views divided by age (not true real-time velocity):\n\n" + rows.map((x,i) => `${i+1}. ${x.title}\n${x.channel} · ${x.views} views · approx ${x.approxVph}/hour\n${x.url}`).join("\n\n") });
  } catch {
    return res.status(500).json({ error: "Trend lookup failed." });
  }
}